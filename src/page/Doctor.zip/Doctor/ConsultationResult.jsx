import React from "react";

export const ConsultationResult = () => {
  return <div>ConsultationResult</div>;
};
